import os
import openai

os.environ["OPENAI_API_KEY"] = "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"
openai.api_key = os.getenv("OPENAI_API_KEY")
name ="elon musk"
response = openai.Completion.create(
  model="text-davinci-003",
  prompt="Q: who is " + name + "? A:",
  temperature=0,
  max_tokens=100,
  top_p=1,
  frequency_penalty=0.0,
  presence_penalty=0.0,
  stop=["\n"]
)


a=response['choices'][0]['text']
print( type('abc bcd'))
print(type(a))

#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